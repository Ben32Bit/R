#' @export

#1st Function
calcImpliedVol = function(df,r,...) {
  r = r/100
  i= 1
  ii = nrow(df)
  ii = as.numeric(ii)
  z <- vector("numeric", ii)

  for (i in 1:ii){ifelse (df[i,2] == "C",
                        print(as.numeric(RQuantLib::EuropeanOptionImpliedVolatility(type = 'call', value = df[i,3],
                                                                    underlying = df[i,4], strike = df[i,1], dividendYield = 0, riskFreeRate = r,
                                                                    maturity = df[i,5], volatility = 20))),
                        print(as.numeric(RQuantLib::EuropeanOptionImpliedVolatility(type = 'put', value = df[i,3],
                                                     underlying = df[i,4], strike = df[i,1], dividendYield = 0, riskFreeRate = r,
                                                     maturity = df[i,5], volatility = 20))))
  }
}


#' @export
#2nd Function
plotImpliedVol = function(df,r,...) {
  a = capture.output(cat(calcImpliedVol(df,r)))
  a = stringr::str_sub(a, 5, 11)
  a = as.numeric(a)

  ii = nrow(df)
  ii = as.numeric(ii)

  plot.new()
  barplot(a, names.arg = c(1:ii),  xlab = "Option Number",
          ylab = "Implied Volatility", main = "IV of Options in Data File")
  grid()
  barplot(a, names.arg = c(1:ii),  xlab = "Option Number",
          ylab = "Implied Volatility", main = "IV of Options in Data File", add = TRUE)
  a

}

